from django.conf.urls.defaults import *

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
admin.autodiscover()

urlpatterns = patterns('',
    # Example:
    # (r'^streetview/', include('streetview.foo.urls')),

    # Uncomment the admin/doc line below to enable admin documentation:
    # (r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    (r'^admin/', include(admin.site.urls)),

    # streetview-specific    
    (r'^$', 'ratestreets.views.viewtasks'),
    (r'^streetview/viewtasks/$', 'ratestreets.views.viewtasks'),
    (r'^streetview/do/(?P<task_id>\d+)$', 'ratestreets.views.dotask'),
    (r'^streetview/ratestreets/(?P<task_id>\d+)$', 'ratestreets.views.ratestreet'),
    (r'^streetview/ratestreets/(?P<task_id>\d+)/(?P<rating_type>\w+)$', 'ratestreets.views.ratestreet'),
    (r'^streetview/submit_rating/(?P<task_id>\d+)$', 'ratestreets.views.submitrating'),
    (r'^accounts/login/$', 'django.contrib.auth.views.login'),
    (r'^logout/$', 'django.contrib.auth.views.logout'),
#    (r'^media/(?P<path>.*)$', 'django.views.static.serve', {'document_root': '/path/to/media'}),
    # this is a giant hack.  Need to figure out the right way to do deployment
    (r'^media/admin/(?P<path>.*)$', 'django.views.static.serve',
        {'document_root': '/home/sjm2186/streetview/streetview/media/admin'}),


)
