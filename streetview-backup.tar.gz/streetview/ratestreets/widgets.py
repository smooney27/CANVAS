from django import forms

class HiddenSelect(forms.Select):
    pass