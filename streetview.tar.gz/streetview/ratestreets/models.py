import logging
from django.db import models
from django.contrib.auth.models import User
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes import generic

# A rating type is a data type for items to record
# has many catagory only relevant for category rating type
class RatingType(models.Model):
    STORAGE_TYPE_CHOICES = (
        (u'BOOL', u'boolean'),
        (u'COUNT', u'count'),
        (u'CATEGORY', u'category'),
        (u'TEXT', u'free-form text'),
    )
    
    name = models.CharField(max_length = 32)
    storage_type = models.CharField(max_length = 32, choices = STORAGE_TYPE_CHOICES)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    # has many Category
    def __unicode__(self):
        return self.name;

# A category is a specific value for a category data type
# (e.g. lowrise, for catagory development type)
class Category(models.Model):
    name = models.CharField(max_length = 32)
    description = models.CharField(max_length = 256)
    value = models.PositiveIntegerField()
    category_group = models.ForeignKey(RatingType)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __unicode__(self):
        return self.name;

# An item is an axis on which a street is rated
class Item(models.Model):
    name = models.CharField(max_length = 32)
    description = models.CharField(max_length = 256)
    source = models.CharField(max_length = 32)
    rating_type = models.ForeignKey(RatingType)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __unicode__(self):
        return self.name;
    def create_rating(self, user, segment):
        if (self.rating_type.storage_type == 'BOOL'):
            new_rating = BooleanRating()
        elif (self.rating_type.storage_type == 'COUNT'):
            new_rating = CountRating()
        elif (self.rating_type.storage_type == 'CATEGORY'):
            new_rating = CategoryRating()
        elif (self.rating_type.storage_type == 'TEXT'):
            new_rating = FreeFormRating()
        new_rating.user = user
        new_rating.segment = segment
        new_rating.item = self
        return new_rating
    def get_rating_class(self):
        if (self.rating_type.storage_type == 'BOOL'):
            return BooleanRating
        elif (self.rating_type.storage_type == 'COUNT'):
            return CountRating
        elif (self.rating_type.storage_type == 'CATEGORY'):
            return CategoryRating
        elif (self.rating_type.storage_type == 'TEXT'):
            return FreeFormRating()
        else:
            logging.debug("unexpected lack of rating class.  Should explode here.")
        
# A module is a collection of items that get data collected
# together.  Note that an item can belong to more than one
# module
class Module(models.Model):
    description = models.CharField(max_length = 256)
    items = models.ManyToManyField(Item)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __unicode__(self):
        return self.description;

# A project is the administrative level for configuring 
# and assigning tasks.
class Project(models.Model):
    director = models.ForeignKey(User, related_name="directed_projects_set")
    managers = models.ManyToManyField(User, related_name="managed_projects_set", blank=True)
    raters = models.ManyToManyField(User, related_name="rated_projects_set", blank=True)
    name = models.CharField(max_length = 32)
    description = models.CharField(max_length = 256)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    # has many Studies
    def __unicode__(self):
        return self.name;


# A study is a data collection unit -- that is, it's the
# collection of locations and items that get rated in one
# block.  Results will be associated with studies.
class Study(models.Model):
    description = models.CharField(max_length = 256)
    project = models.ForeignKey(Project)
    modules = models.ManyToManyField(Module)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    # has many Locations
    def __unicode__(self):
        return self.description;

# A segment is physical location in the real world that 
# users of this application rate.  Note that a segment
# can be a single point if its start and end are the same
# points.
class Segment(models.Model):
    study = models.ForeignKey(Study)
    point_of_view = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    start_lat = models.FloatField()
    start_lng = models.FloatField()
    end_lat = models.FloatField()
    end_lng = models.FloatField()
    def __unicode__(self):
        return '(%f,%f)->(%f,%f)' % (self.start_lat, self.start_lng, self.end_lat, self.end_lng);

# A rating task is the item that tracks the need for a rating
# to be completed by a user
class RatingTask(models.Model):
    user = models.ForeignKey(User)
    segment = models.ForeignKey(Segment)
    module = models.ForeignKey(Module)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    first_prompted_at = models.DateTimeField(blank=True, null=True)
    completed_at = models.DateTimeField(blank=True, null=True)
# todo$ re-enable before next db reset.
    class Meta:
        unique_together = ('user', 'segment', 'module')
    def __unicode__(self):
        return '%s:(%f,%f)->(%f,%f)' % (self.user.username, self.segment.start_lat, self.segment.start_lng, self.segment.end_lat, self.segment.end_lng);
    def find_or_create_ratings(self, type):
        # todo$ should be all ratings
        # todo$ should verify that narrow by module works
#        ratings_queryset = BooleanRating.objects.filter(user=self.user).filter(segment=self.segment).filter(item__module=self.module)
#        # todo$ this should usually be all or nothing, but we should really 
#        # be iterating the list and creating any ratings that don't exist 
#        # just in case
#        if ratings_queryset:
#            return ratings_queryset
#        else:
#            for item in self.module.items.all():
#                logging.debug('Creating new rating...')
#                found = False
#                for rating_object in ratings_queryset:
#                    if rating_object.item == item:
#                        found = True
#                        break
#                if found == False:
#                    new_rating = BooleanRating()
#                    new_rating.user = self.user
#                    new_rating.segment = self.segment
#                    new_rating.item = item
#                    new_rating.save()
#            return BooleanRating.objects.filter(user=self.user).filter(segment=self.segment).filter(item__module=self.module)
        if (type == BooleanRating):
            ratings = BooleanRating.find_or_create_ratings_for_task(self)
        elif (type == CountRating):
            ratings = CountRating.find_or_create_ratings_for_task(self)
        return ratings

# A rating is the base class for a piece of data collected
# by a user
class Rating(models.Model):
    user = models.ForeignKey(User)
    segment = models.ForeignKey(Segment)
    item = models.ForeignKey(Item)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __init__(self, *args, **kwargs):
        logging.debug('Rating init called')
        models.Model.__init__(self, *args, **kwargs)
    @classmethod
    def find_or_create_ratings_for_task(cls, task):
        ratings_queryset = cls.objects.filter(user=task.user).filter(segment=task.segment).filter(item__module=task.module)
        # todo$ this should usually be all or nothing, but we should really 
        # be iterating the list and creating any ratings that don't exist 
        # just in case
        if ratings_queryset:
            return ratings_queryset
        else:
            for item in task.module.items.all():
                if item.get_rating_class() == cls:
                    logging.debug('Creating new rating...')
                    found = False
                    for rating_object in ratings_queryset:
                        if rating_object.item == item:
                            found = True
                            break
                    if found == False:
                        new_rating = item.create_rating(task.user, task.segment)
                        new_rating.save()
            return cls.objects.filter(user=task.user).filter(segment=task.segment).filter(item__module=task.module)
    class Meta:
        abstract = True
        unique_together = ('user', 'segment', 'item')

class BooleanRating(Rating):
    rating = models.NullBooleanField()
    
class CategoryRating(Rating):
    rating = models.PositiveIntegerField(null=True)

class CountRating(Rating):
    rating = models.PositiveIntegerField(null=True)

class FreeFormRating(Rating):
    rating = models.CharField(max_length = 1024, null=True)

    