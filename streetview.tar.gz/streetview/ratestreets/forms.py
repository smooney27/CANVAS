import logging
from django.forms import Form
from django.forms import ModelForm
from django.forms import Textarea
from django.forms import BooleanField
from django.forms import IntegerField
from ratestreets.models import RatingTask
from ratestreets.models import Rating
from ratestreets.models import BooleanRating
from ratestreets.models import CountRating
from django.forms.models import modelformset_factory

RatingFormSet = modelformset_factory(Rating)

class RatingTaskForm(Form):

    def __init__(self, task):
        Form.__init__(self)
        self.rating_task = task
        self.item_forms = []
        for item in self.rating_task.module.items.all():
            item_form = None
            logging.debug('item rating type storage type: ' + item.rating_type.storage_type)
            if (item.rating_type.storage_type == 'BOOL'):
                item_form = BooleanRatingForm(item)
            # todo other classes
            self.item_forms.append(item_form)
    def html(self):
        logging.debug('html called')
        html = ''
        for item_form in self.item_forms:
            if item_form != None:
                html += '<p>Question ' + ': ' + item_form.as_p() + '</p>'
        return html
    class Meta:
        model = RatingTask
    

class BooleanRatingForm(ModelForm):
    rating = BooleanField(required=False)
    def __init__(self, *args, **kwargs):
        ModelForm.__init__(self, *args, **kwargs)
        instance = kwargs['instance']
        if instance:
            self.fields['rating'].label = instance.item.description
    class Meta:
        model = BooleanRating
        exclude = ('user','item', 'segment') 
        
BooleanRatingFormSet = modelformset_factory(BooleanRating, form=BooleanRatingForm, extra=0)

class CountRatingForm(ModelForm):
    rating = IntegerField(required=False)
    def __init__(self, *args, **kwargs):
        ModelForm.__init__(self, *args, **kwargs)
        instance = kwargs['instance']
        if instance:
            self.fields['rating'].label = instance.item.description
    class Meta:
        model = CountRating
        exclude = ('user','item', 'segment') 

CountRatingFormSet = modelformset_factory(CountRating, form=CountRatingForm, extra=0)
