import logging
from django.forms import *
from ratestreets.models import *
from ratestreets.widgets import *
from django.forms.models import modelformset_factory

RatingFormSet = modelformset_factory(Rating)

class SegmentImportForm(Form):
    study = ModelChoiceField(queryset=None)
    segment_csv = FileField()
    def __init__(self, request, *args, **kwargs):
        Form.__init__(self, *args, **kwargs)
        self.fields['study'].queryset=Study.objects.filter(project__managers=request.user)


class UserForm(ModelForm):
    rated_projects = ModelMultipleChoiceField(None, required=False, label='Assigned to Rate Projects')
    def __init__(self, request, *args, **kwargs):
        ModelForm.__init__(self, *args, **kwargs)
        self.fields['rated_projects'].queryset = Project.objects.filter(managers=request.user)
        self.fields['rated_projects'].initial = Project.objects.filter(raters=self.instance)
    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'rated_projects')
#        fields = ('first_name', 'last_name', 'email', 'directed_projects_set', 'managed_projects_set', 'rated_projects_set',)
#        exclude = ('password')

class RatingForm(ModelForm):
    IMPEDIMENT_CHOICES = (
                          ('', 'Select'),
                          ('0', 'Other'),
                          ('1', 'Blocked'),
                          ('2', 'Too Far'),
                          ('3', 'Too Blurry'),
                          ('4', 'Too Dim'),
                          )
    impediment = TypedChoiceField(required=False, 
                                  choices=IMPEDIMENT_CHOICES, 
                                  coerce=coerce_impediment,
                                  empty_value=None,
                                  label='',
                                  widget=forms.Select(attrs={'style':'display:none'}))
    

class BooleanRatingForm(RatingForm):
    YES_NO_CHOICES = (
                      ('', 'Select'),
                      ('1', 'Yes'),
                      ('2', 'No'),
                      ('0', 'Cannot tell'),
                      )
    rating = TypedChoiceField(required=False, 
                              choices=YES_NO_CHOICES, 
                              coerce=coerce_boolean,
                              empty_value=None)
    def __init__(self, *args, **kwargs):
        ModelForm.__init__(self, *args, **kwargs)
        instance = kwargs['instance']
        if instance:
            self.fields['rating'].label = instance.item.description
    class Meta:
        model = BooleanRating
        fields = ('rating', 'impediment')
        
BooleanRatingFormSet = modelformset_factory(BooleanRating, form=BooleanRatingForm, extra=0)

class CountRatingForm(RatingForm):
    rating = IntegerField(required=False)
    cannot_tell = BooleanField(label="cannot tell", required=False)
    def __init__(self, *args, **kwargs):
        ModelForm.__init__(self, *args, **kwargs)
        instance = kwargs['instance']
        if instance:
            self.fields['rating'].label = instance.item.description
            self.fields['cannot_tell'].initial = instance.impediment != None
    def clean(self):
        rating = self.cleaned_data['rating']
        impediment = self.cleaned_data['impediment']
        logging.debug('rating: ' + str(rating))
        logging.debug('impediment: ' + str(impediment))
        if ((rating != None) and (impediment != None)):
            raise ValidationError("Please set count to blank if you cannot tell for sure")
        return self.cleaned_data
    class Meta:
        model = CountRating
        fields = ('rating', 'cannot_tell', 'impediment')

CountRatingFormSet = modelformset_factory(CountRating, form=CountRatingForm, extra=0)

class CategoryRatingForm(RatingForm):
    DEFAULT_CHOICES = (
                      ('', 'Select'),
                      )
    rating = TypedChoiceField(required=False, 
                              choices=DEFAULT_CHOICES, 
                              coerce=coerce_category,
                              empty_value=None)
    def __init__(self, *args, **kwargs):
        ModelForm.__init__(self, *args, **kwargs)
        instance = kwargs['instance']
        if instance:
            self.fields['rating'].label = instance.item.description
            category_choices = []
            category_choices.append(('','Select'))
            category_choices.append(('-1','Cannot Tell'))
            for category in instance.item.rating_type.values.all():
                tuple = (category.db_value, category.name)
                category_choices.append(tuple)
            self.fields['rating'].choices = category_choices
    def clean(self):
        rating = self.cleaned_data['rating']
        impediment = self.cleaned_data['impediment']
        if ((rating == None) and (impediment == None)):
            raise ValidationError("Please select a value or 'Cannot Tell' and a reason why not.")
        return self.cleaned_data
    class Meta:
        model = CategoryRating
        fields = ('rating', 'impediment')
        
CategoryRatingFormSet = modelformset_factory(CategoryRating, form=CategoryRatingForm, extra=0)


class FreeFormRatingForm(RatingForm):
    rating = CharField(max_length = 1024, required=False, widget=Textarea)
    def __init__(self, *args, **kwargs):
        ModelForm.__init__(self, *args, **kwargs)
        instance = kwargs['instance']
        if instance:
            self.fields['rating'].label = instance.item.description
    class Meta:
        model = FreeFormRating
        fields = ('rating', 'impediment')

FreeFormRatingFormSet = modelformset_factory(FreeFormRating, form=FreeFormRatingForm, extra=0)

class ProjectForm(ModelForm):
    def __init__(self, request, *args, **kwargs):
        ModelForm.__init__(self, *args, **kwargs)
        self.fields['director'].queryset = User.objects.filter(is_staff=True)
        self.fields['managers'].queryset = User.objects.filter(is_staff=True)
        self.fields['raters'].queryset = User.objects.filter(is_staff=False)
    class Meta:
        model = Project

class StudyForm(ModelForm):
    raters = ModelMultipleChoiceField(User.objects.all(), required=False, label='Raters')
    def __init__(self, request, *args, **kwargs):
        ModelForm.__init__(self, *args, **kwargs)
        self.fields['project'].queryset = Project.objects.filter(managers=request.user)
    class Meta:
        model = Study

