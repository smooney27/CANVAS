import logging
import csv
from django.db import models
from django.contrib.auth.models import User
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes import generic
from ratestreets.validators import *

# A category is a specific value for a category data type
# (e.g. lowrise, for category development type)
class Category(models.Model):
    name = models.CharField(max_length = 32)
    description = models.CharField(max_length = 256)
    db_value = models.PositiveIntegerField()
#    category_group = models.ForeignKey(RatingType)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __unicode__(self):
        return self.name;

# A rating type is a data type for items to record
# has many catagory only relevant for category rating type
class RatingType(models.Model):
    STORAGE_TYPE_CHOICES = (
#        (u'BOOL', u'boolean'),
#        (u'COUNT', u'count'),
        (u'CATEGORY', u'category'),
        (u'TEXT', u'free-form text'),
    )
    
    description = models.CharField(max_length = 256)
    storage_type = models.CharField(max_length = 32, choices = STORAGE_TYPE_CHOICES)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    values = models.ManyToManyField(Category)
    # has many Category
    def __unicode__(self):
        return self.name;


# An item is an axis on which a street is rated
class Item(models.Model):
    name = models.CharField(max_length = 32)
    description = models.CharField(max_length = 256)
    instrument = models.CharField(max_length = 32, null=True)
    number = models.FloatField(null=True)
    category_1 = models.CharField(max_length = 32, null=True)
    category_2 = models.CharField(max_length = 32, null=True)
    rating_type = models.ForeignKey(RatingType)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __unicode__(self):
        return self.name;
    def create_rating(self, user, segment):
        if (self.rating_type.storage_type == 'BOOL'):
            new_rating = BooleanRating()
        elif (self.rating_type.storage_type == 'COUNT'):
            new_rating = CountRating()
        elif (self.rating_type.storage_type == 'CATEGORY'):
            new_rating = CategoryRating()
        elif (self.rating_type.storage_type == 'TEXT'):
            new_rating = FreeFormRating()
        new_rating.user = user
        new_rating.segment = segment
        new_rating.item = self
        return new_rating
    def get_rating_class(self):
        if (self.rating_type.storage_type == 'BOOL'):
            return BooleanRating
        elif (self.rating_type.storage_type == 'COUNT'):
            return CountRating
        elif (self.rating_type.storage_type == 'CATEGORY'):
            return CategoryRating
        elif (self.rating_type.storage_type == 'TEXT'):
            return FreeFormRating
        else:
            logging.debug("unexpected lack of rating class.  Should explode here.")
        
# A module is a collection of items that get data collected
# together.  Note that an item can belong to more than one
# module
class Module(models.Model):
    description = models.CharField(max_length = 256)
    items = models.ManyToManyField(Item)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __unicode__(self):
        return self.description;
    def contains_items_of_rating_type(self, cls):
        logging.debug('contains_items_of_rating_type called with class' + str(cls))
        # todo$ this could be a perf bottleneck
        for item in self.items.all():
            if item.get_rating_class() == cls:
                return True
        return False

# A project is the administrative level for configuring 
# and assigning tasks.
class Project(models.Model):
    director = models.ForeignKey(User, related_name="directed_projects_set")
    managers = models.ManyToManyField(User, related_name="managed_projects_set", blank=True)
    raters = models.ManyToManyField(User, related_name="rated_projects_set", blank=True)
    name = models.CharField(max_length = 32)
    description = models.CharField(max_length = 256)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    # has many Studies
    def __unicode__(self):
        return self.name;


# A study is a data collection unit -- that is, it's the
# collection of locations and items that get rated in one
# block.  Results will be associated with studies.
class Study(models.Model):
    description = models.CharField(max_length = 256)
    project = models.ForeignKey(Project)
    modules = models.ManyToManyField(Module)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    # has many Locations
    def __unicode__(self):
        return self.description;
    def percent_complete(self):
        total_tasks = self.total_tasks()
        if (total_tasks == 0):
            return 0
        else:
            completed_tasks = self.completed_tasks()
            return (100*completed_tasks)/total_tasks
    def total_tasks(self):
        return RatingTask.objects.filter(segment__study=self).count();
    def completed_tasks(self):
        return RatingTask.objects.filter(segment__study=self, completed_at__isnull=False).count()
    def save(self, *args, **kwargs):
        # Call the base class to do the real save.
        super(Study, self).save(*args, **kwargs)
        # Then make sure all tasks exist in the DB.
        self.ensure_all_tasks_exist()
    def ensure_all_tasks_exist(self):
        for rater in self.project.raters.all():
            for module in self.modules.all():
                for segment in self.segment_set.all():
                    task = RatingTask.objects.get_or_create(user=rater, module=module, segment=segment)
    def add_segments_from_csv(self, uploaded_file):
        try:
            uploaded_file.read()
            reader = csv.reader(uploaded_file, dialect='excel')
            for index, row in enumerate(reader):
                start_lng = float(row[4])
                start_lat = float(row[5])
                end_lng = float(row[6])
                end_lat = float(row[7])
                logging.debug("Adding street segment from (%f, %f)->(%f, %f) to study %s" % (start_lat, start_lng, end_lat, end_lng, self.description))
                new_segment = Segment.objects.get_or_create(study=self, point_of_view=0, start_lat=start_lat, start_lng=start_lng, end_lat=end_lat, end_lng=end_lng)[0]
            # Once we've added the segments, make sure the tasks exist.
            self.ensure_all_tasks_exist()
        finally:
            uploaded_file.close()

# A segment is physical location in the real world that 
# users of this application rate.  Note that a segment
# can be a single point if its start and end are the same
# points.
class Segment(models.Model):
    study = models.ForeignKey(Study)
    point_of_view = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    start_lat = models.FloatField()
    start_lng = models.FloatField()
    end_lat = models.FloatField()
    end_lng = models.FloatField()
    def __unicode__(self):
        return '(%f,%f)->(%f,%f)' % (self.start_lat, self.start_lng, self.end_lat, self.end_lng);

# A rating task is the item that tracks the need for a rating
# to be completed by a user
class RatingTask(models.Model):
    user = models.ForeignKey(User)
    segment = models.ForeignKey(Segment)
    module = models.ForeignKey(Module)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    first_prompted_at = models.DateTimeField(blank=True, null=True)
    completed_at = models.DateTimeField(blank=True, null=True)
# todo$ re-enable before next db reset.
    class Meta:
        unique_together = ('user', 'segment', 'module')
    def __unicode__(self):
        return '%s:(%f,%f)->(%f,%f)' % (self.user.username, self.segment.start_lat, self.segment.start_lng, self.segment.end_lat, self.segment.end_lng);
    def find_or_create_ratings(self, type):
        if (type == BooleanRating):
            ratings = BooleanRating.find_or_create_ratings_for_task(self)
        elif (type == CountRating):
            ratings = CountRating.find_or_create_ratings_for_task(self)
        elif (type == CategoryRating):
            ratings = CategoryRating.find_or_create_ratings_for_task(self)
        elif (type == FreeFormRating):
            ratings = FreeFormRating.find_or_create_ratings_for_task(self)
        # todo$ other rating types
        return ratings
    def get_next_rating_type(self, current_type_name):
        # todo$ this mixture of type name and class is cheesy but helpful
        # for dealing with text passed to URL.  Need to investigate best
        # practices.
        if (current_type_name == None and 
            self.module.contains_items_of_rating_type(BooleanRating)):
            return 'count'
        elif ((current_type_name == None or
              current_type_name == 'boolean') and 
            self.module.contains_items_of_rating_type(CountRating)):
            return 'count'
        elif ((current_type_name == None or
               current_type_name == 'boolean' or
               current_type_name == 'count') and
               self.module.contains_items_of_rating_type(CategoryRating)):
            return 'category'
        elif ((current_type_name == None or
               current_type_name == 'boolean' or
               current_type_name == 'count' or
               current_type_name == 'category') and
               self.module.contains_items_of_rating_type(FreeFormRating)):
            return 'text'
        else:
            return None
# A rating is the base class for a piece of data collected
# by a user
class Rating(models.Model):
    user = models.ForeignKey(User)
    segment = models.ForeignKey(Segment)
    item = models.ForeignKey(Item)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    impediment = models.PositiveIntegerField(validators = [validate_impediment], null=True)
    def __init__(self, *args, **kwargs):
        logging.debug('Rating init called')
        models.Model.__init__(self, *args, **kwargs)
    @classmethod
    def find_or_create_ratings_for_task(cls, task):
        # todo$ should verify that narrow by module works
        ratings_queryset = cls.objects.filter(user=task.user).filter(segment=task.segment).filter(item__module=task.module)
        # todo$ this should usually be all or nothing, but we should really 
        # be iterating the list and creating any ratings that don't exist 
        # just in case
        anything_added = False
        for item in task.module.items.all():
            if item.get_rating_class() == cls:
                logging.debug('Creating new rating...')
                found = False
                for rating_object in ratings_queryset:
                    if rating_object.item == item:
                        found = True
                        break
                if found == False:
                    new_rating = item.create_rating(task.user, task.segment)
                    new_rating.save()
                    anything_added = True
        # Refresh the queryset if we added any ratings
        if anything_added:
            ratings_queryset = cls.objects.filter(user=task.user).filter(segment=task.segment).filter(item__module=task.module)
        return ratings_queryset
    
    class Meta:
        abstract = True
        unique_together = ('user', 'segment', 'item')

class BooleanRating(Rating):
    rating = models.PositiveIntegerField(validators = [validate_boolean], null=True)

class CategoryRating(Rating):
    rating = models.PositiveIntegerField(validators = [validate_category], null=True)

class CountRating(Rating):
    rating = models.PositiveIntegerField(null=True)

class FreeFormRating(Rating):
    rating = models.CharField(max_length = 1024, null=True)

    