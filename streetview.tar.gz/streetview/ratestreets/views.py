import logging
from django.shortcuts import render_to_response
from django.shortcuts import redirect
from django.shortcuts import get_object_or_404
from ratestreets.models import RatingTask
from ratestreets.models import Rating
from ratestreets.models import BooleanRating
from ratestreets.models import CountRating
from ratestreets.forms import RatingTaskForm
from ratestreets.forms import RatingFormSet
from ratestreets.forms import BooleanRatingFormSet
from ratestreets.forms import CountRatingFormSet
from django.template import RequestContext
from django.contrib.auth.decorators import login_required

# Create your views here.
@login_required
def viewtasks(request):
    tasks = RatingTask.objects.filter(user=request.user)
    return render_to_response('ratestreets/viewtasks.html', {'tasks': tasks}, context_instance=RequestContext(request))

@login_required
def ratestreet(request, task_id, rating_type='boolean'):
    task = get_object_or_404(RatingTask, pk=task_id)
    if (request.method =='POST'):
        if (rating_type == 'boolean'):
            formset = BooleanRatingFormSet(request.POST)
            if (formset.is_valid()):
                formset.save()
                return redirect('ratestreets.views.ratestreet', task_id=task_id, rating_type='count')
        elif (rating_type == 'count'):
            formset = CountRatingFormSet(request.POST)
            if (formset.is_valid()):
                formset.save()
                return render_to_response('ratestreets/success.html', {'formset': formset, 'task': task}, context_instance=RequestContext(request))
    else:
#    if (request.method == 'POST'):
#        form = RatingTaskForm(request.POST)
#        if (form.task != task):
#            # todo -- is this the right way to barf here?
#            raise 'Wrong task created with taskform!'
#        if (form.is_valid()):
#            # todo$ automatically go to next task
#            return HttpResponseRedirect('ratestreets/viewtasks.html')
#    else:

    
#    form = RatingTaskForm(task)
#    return render_to_response('ratestreets/ratestreet.html', {'form': form})

    # todo -- can I do this for the abstract base class?
    # todo -- figure out how to filter by location, too.
        if (rating_type == 'boolean'):
            ratings = task.find_or_create_ratings(BooleanRating)
            formset = BooleanRatingFormSet(queryset=ratings)
        elif (rating_type == 'count'):
            ratings = task.find_or_create_ratings(CountRating)
            formset = CountRatingFormSet(queryset=ratings)
    # todo try using a form set.
#    formset = BooleanRatingFormSet(queryset=BooleanRating.objects.all())
    return render_to_response('ratestreets/ratestreet.html', {'formset': formset, 'task': task}, context_instance=RequestContext(request))


@login_required
def dotask(request, task_id):
    task = RatingTask.objects.get(id = task_id)
    return render_to_response('ratestreets/dotask.html', {'task': task}, context_instance=RequestContext(request))

@login_required
def submitrating(request, task_id):
    task = get_object_or_404(RatingTask, pk=task_id)
    ## Loop over submitted item responses.
    ratings = []
    for item in task.module.items.all():
        form_field_name = "item_" + str(item.id)
        try: 
            post_params = request.POST[form_field_name]
        except (KeyError): 
            return render_to_response('ratestreets/dotask.html', {'task': task, 'error_message': 'no item selected'}, context_instance=RequestContext(request))
        else:
            # todo -- obviously, this should be by item rating type.
            # todo -- use django form objects?
            rating = BooleanRating()
            rating.user = request.user
            rating.location = task.location
            rating.item = item
            rating.rating = request.POST[form_field_name]
            rating.save()
            ratings.append(rating)
    return render_to_response('ratestreets/submitrating.html', {'task': task, 'rating_count':len(ratings)}, context_instance=RequestContext(request))
